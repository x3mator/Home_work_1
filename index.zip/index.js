'use strict';

const nameGood = 'булочка'
const piecesGood = 21
const category = 'булочные изделия'
const price = 3

console.log(`У нас есть ${piecesGood} ${nameGood} из категории "${category}", стоимостью ${price}$.`)
console.log(`Общая сумма товара: ${piecesGood*price}$.`)